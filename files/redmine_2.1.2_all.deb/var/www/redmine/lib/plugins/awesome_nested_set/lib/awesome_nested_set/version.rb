module AwesomeNestedSet
  VERSION = '2.1.0' unless defined?(::AwesomeNestedSet::VERSION)
end
